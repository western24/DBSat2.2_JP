



SET VERIFY OFF
SET FEEDBACK OFF
SET TIMING OFF
SET ECHO OFF 
SET WRAP OFF
SET LINESIZE 32767
SET TRIMSPOOL ON 
SET TRIMOUT ON 
SET SERVEROUTPUT ON SIZE UNLIMITED
WHENEVER SQLERROR EXIT
WHENEVER OSERROR EXIT 

var version VARCHAR2(30);
exec :version := '2.2 (September 2019)';
var v_spool_file VARCHAR2(1000);
var skip_os VARCHAR2(1);
var err_buf VARCHAR2(1000);
exec :skip_os := 'Y';
exec :err_buf := '';

DECLARE
  required_roles       NUMBER;
  v_path               VARCHAR2(1000);
  v_output_file        VARCHAR2(1000);
BEGIN
  SELECT count(*) INTO required_roles
  FROM session_roles
  WHERE role in ('SELECT_CATALOG_ROLE');

  IF USER <> 'SYS' and required_roles = 0 THEN
    RAISE_APPLICATION_ERROR(-20000,
                     'The SELECT_CATALOG_ROLE role is required.');
  END IF;

  v_path := '&1';

  IF LENGTH(v_path) > 995 THEN
    RAISE_APPLICATION_ERROR(-20001, 'The input value is too long.');
  END IF;

  v_output_file := v_path || '.json';

  SELECT v_output_file INTO :v_spool_file FROM sys.DUAL;
END;
/

ALTER SESSION SET nls_date_format="DD-MM-YYYY HH24:MI";


SET TERMOUT ON
exec SYS.DBMS_OUTPUT.PUT_LINE('Setup complete.');
SET TERMOUT OFF

column scol new_value x_spool_file noprint
select :v_spool_file scol from sys.dual;

SPOOL &x_spool_file

WHENEVER SQLERROR CONTINUE

DECLARE
  db_version  VARCHAR2(30);

  FUNCTION ENCODE_CHAR(col_val VARCHAR2) RETURN VARCHAR2 AS
    nc             NCHAR;
    col_val_output VARCHAR2(4100) := '';
    len            NUMBER;
    str_len        NUMBER;
    hex            VARCHAR2(128);
  BEGIN
    len := 0;
    IF col_val IS NOT NULL THEN
      str_len := LENGTH(col_val);
      FOR k in 1..str_len LOOP
        IF len > 4000 THEN
          EXIT;
        END IF;
        nc := SUBSTR(col_val, k, 1);
        IF ASCII(nc) < 32 OR ASCII(nc) = 127 THEN
          hex := TO_CHAR(ASCII(nc), '0x');
          hex := REGEXP_REPLACE(hex, '\s');
          col_val_output := col_val_output || '\u00' || hex;
          len := len + LENGTH(hex) + 4;
        ELSIF ASCII(nc) = 34 THEN
          col_val_output := col_val_output || '\"';
          len := len + 2;
        ELSIF ASCII(nc) = 92 THEN
          col_val_output := col_val_output || '\\';
          len := len + 2;
        ELSIF ASCII(nc) > 127 THEN
          col_val_output := col_val_output || '\u' || substr(ASCIISTR(nc), 2);
          len := len + 6;
        ELSE
          col_val_output := col_val_output || nc;
          len := len + 1;
        END IF;
      END LOOP;
    END IF;
    RETURN col_val_output;
  END;

  PROCEDURE SAT_COLLECT_SQL(name VARCHAR2,
                            version NUMBER,
                            sql_stmt VARCHAR2, 
                            bool_expr VARCHAR2 DEFAULT '') AS
    bool_regex_str  VARCHAR2(1024);
    c         NUMBER;
    d         NUMBER;
    TYPE      t_varlist IS VARRAY(32) OF SYS.DBMS_SQL.VARCHAR2_TABLE;
    TYPE      t_numlist IS VARRAY(32) OF SYS.DBMS_SQL.NUMBER_TABLE;
    TYPE      t_datelist IS VARRAY(32) OF SYS.DBMS_SQL.DATE_TABLE;
    var_list  t_varlist := t_varlist();
    num_list  t_numlist := t_numlist();
    date_list t_datelist := t_datelist();
    indx      NUMBER := 1;
    col_count NUMBER;
    desc_tab  SYS.DBMS_SQL.DESC_TAB;
    row_str   VARCHAR2(32767);
    row_count NUMBER := 0;
    col_type  BINARY_INTEGER;
    col_name  VARCHAR2(128);
    col_val_output VARCHAR2(4100) := '';
    pos1      NUMBER;
    pos2      NUMBER;
    TYPE      t_regex_list IS VARRAY(32) OF VARCHAR2(1024);
    TYPE      t_bool_list IS VARRAY(32) OF BOOLEAN;
    regex_list   t_regex_list := t_regex_list();
    convert_list t_bool_list := t_bool_list();
    nl        CHAR(1) := chr(10);
    c_varcol  CONSTANT NUMBER := 1;
    c_numcol  CONSTANT NUMBER := 2;
    c_datecol CONSTANT NUMBER := 12;
    c_timecol CONSTANT NUMBER := 180;
    c_timezcol CONSTANT NUMBER := 181;
    c_timelzcol CONSTANT NUMBER := 231;
  BEGIN
    bool_regex_str := bool_expr;
    c := SYS.DBMS_SQL.OPEN_CURSOR;
    SYS.DBMS_SQL.PARSE(c, sql_stmt, SYS.DBMS_SQL.NATIVE);
    SYS.DBMS_SQL.DESCRIBE_COLUMNS(c, col_count, desc_tab);
    
    var_list.extend(col_count);
    num_list.extend(col_count);
    date_list.extend(col_count);
    regex_list.extend(col_count);
    convert_list.extend(col_count);

    bool_regex_str := UPPER(bool_regex_str);
    bool_regex_str := REGEXP_REPLACE(bool_regex_str, '\s');

    IF LENGTH(bool_regex_str) > 0 AND
      SUBSTR(bool_regex_str, LENGTH(bool_regex_str) - 1) <> ';' THEN
      bool_regex_str := bool_regex_str || ';';
    END IF;

    row_str := '"' || name || '": {"version": ' || version || ',' || nl ||
               chr(9) || '"columns": [';

    FOR i IN 1..col_count LOOP
      col_name := desc_tab(i).col_name;
      convert_list(i) := FALSE;

      pos1 := INSTR(bool_regex_str, col_name);

      IF pos1 > 0 THEN -- the column needs to be coverted to boolean type
        pos1 := pos1 + LENGTH(col_name) + 1;
        pos2 := INSTR(bool_regex_str, ';', pos1);

        IF pos2 > pos1 THEN
          convert_list(i) := TRUE;
          regex_list(i) := SUBSTR(bool_regex_str, pos1, pos2-pos1);
        END IF;
      END IF;
      
      col_name := LOWER(col_name);
      col_name := REGEXP_REPLACE(col_name, '\s');

      row_str := row_str || '"' || col_name || '"';
      IF i < col_count THEN
        row_str := row_str || ', ';
      ELSE
        row_str := row_str || '], ';
      END IF;

      col_type := desc_tab(i).col_type;
      IF col_type = c_varcol THEN             -- VARCHAR2
        SYS.DBMS_SQL.DEFINE_ARRAY(c, i, var_list(i), 1, indx);
      ELSIF col_type = c_numcol THEN          -- NUMBER
        SYS.DBMS_SQL.DEFINE_ARRAY(c, i, num_list(i), 1, indx);
      ELSIF col_type = c_datecol OR col_type = c_timecol OR 
            col_type = c_timezcol OR col_type = c_timelzcol THEN        -- DATE/TIMESTAMP [w/ [LOCAL]TIMEZONE]
        SYS.DBMS_SQL.DEFINE_ARRAY(c, i, date_list(i), 1, indx);
      END IF;
    END LOOP;

    /* execute SQL statement */
    d := SYS.DBMS_SQL.EXECUTE(c);

    /* retrieve column values to column table */
    LOOP
      EXIT WHEN SYS.DBMS_SQL.FETCH_ROWS(c) = 0;
      row_count := row_count + 1;
      FOR i IN 1..col_count LOOP
        col_type := desc_tab(i).col_type;
        IF col_type = c_varcol THEN
          SYS.DBMS_SQL.COLUMN_VALUE(c, i, var_list(i));
        ELSIF col_type = c_numcol THEN
          SYS.DBMS_SQL.COLUMN_VALUE(c, i, num_list(i));
        ELSIF col_type = c_datecol OR col_type = c_timecol OR 
              col_type = c_timezcol OR col_type = c_timelzcol THEN
          SYS.DBMS_SQL.COLUMN_VALUE(c, i, date_list(i));
        END IF;
      END LOOP;
    END LOOP;

    SYS.DBMS_SQL.CLOSE_CURSOR(c);

    SYS.DBMS_OUTPUT.PUT_LINE(row_str);

    SYS.DBMS_OUTPUT.PUT(chr(9) || '"data": [');
    FOR i IN 1..row_count LOOP
      row_str := '[';
      FOR j IN 1..col_count LOOP
        col_type := desc_tab(j).col_type;
        IF col_type = c_varcol THEN
          IF convert_list(j) THEN
            IF REGEXP_LIKE(var_list(j)(i), regex_list(j))  THEN
              row_str := row_str || 'true';
            ELSE
              row_str := row_str || 'false';
            END IF;
          ELSE
            col_val_output := ENCODE_CHAR(var_list(j)(i));
            row_str := row_str || '"' || col_val_output || '"';
          END IF;
        ELSIF col_type = c_numcol THEN
          IF num_list(j)(i) IS NULL THEN
            row_str := row_str || 'null';
          ELSE
            row_str := row_str || TO_CHAR(num_list(j)(i));
          END IF;
        ELSIF col_type = c_datecol OR col_type = c_timecol OR 
              col_type = c_timezcol OR col_type = c_timelzcol THEN
          row_str := row_str || '"' || date_list(j)(i) || '"';
        END IF;
        IF j < col_count THEN
          row_str := row_str || ',';
        END IF;
      END LOOP;
      row_str := row_str || ']';
      SYS.DBMS_OUTPUT.PUT_LINE(row_str);
      IF i < row_count THEN
        SYS.DBMS_OUTPUT.PUT(chr(9)||'        ,');
      END IF;
    END LOOP;
    SYS.DBMS_OUTPUT.PUT_LINE(chr(9)||'        ]},');

  EXCEPTION
    WHEN OTHERS THEN
      IF SYS.DBMS_SQL.IS_OPEN(c) THEN 
        SYS.DBMS_SQL.CLOSE_CURSOR(c); 
      END IF;
      /* Ignore USERENV invalid values*/ 
      IF SQLCODE NOT IN (-942, -904, -2003) THEN
        :err_buf := :err_buf || 'Query: ' || sql_stmt || nl || 
                    'Error: ' || SQLERRM || nl || nl;
      END IF;
  END;
BEGIN
  SYS.DBMS_OUTPUT.PUT_LINE('{');

  sat_collect_sql(name      => 'date_and_release', 
                  version   => 1, 
                  sql_stmt  => 'SELECT systimestamp collection_date, 
                                       version release 
                                FROM sys.v_$instance');

  sat_collect_sql(name      => 'date_and_release', 
                  version   => 2, 
                  sql_stmt  => 'SELECT systimestamp collection_date, 
                                       version_full release 
                                FROM sys.v_$instance');

  sat_collect_sql(name      => 'instance_name',
                  version   => 1,
                  sql_stmt  => 'SELECT instance_name inst_name 
                                FROM sys.v_$instance');


  sat_collect_sql(name      => 'db_identity', 
                  version   => 1, 
                  sql_stmt  => 'SELECT name, log_mode, platform_name platform,
                                       database_role dg_role,
                                       dataguard_broker dg_broker,
                                       flashback_on flashback,
                                       controlfile_type controlfile,
                                       switchover_status, created 
                                FROM sys.v_$database');

  sat_collect_sql(name      => 'db_pdbs',
                  version   => 1,
                  sql_stmt  => 'SELECT con_id, name
                                FROM sys.v_$containers
                                WHERE con_id <> 0'); 

  sat_collect_sql(name      => 'db_version',
                  version   => 1,
                  sql_stmt  => 'SELECT banner 
                                FROM sys.v_$version');

  sat_collect_sql(name      => 'db_file_directory',
                  version   => 1,
                  sql_stmt  => 'SELECT value
                                FROM v$parameter
                                WHERE name = ''db_create_file_dest'''); 

  sat_collect_sql(name      => 'registry_history',
                  version   => 12,
                  sql_stmt  => 'SELECT action_time, action, namespace, version,
                                       bundle_series, id, comments 
                                FROM sys.dba_registry_history
                                ORDER BY action_time desc'); 

  sat_collect_sql(name      => 'registry_sqlpatch',
                  version   => 2,
                  sql_stmt  => 'SELECT action_time, action, version,
                                       bundle_series, bundle_id, description
                                FROM sys.dba_registry_sqlpatch
                                WHERE status = ''SUCCESS''
                                ORDER BY action_time desc');

  sat_collect_sql(name      => 'registry_sqlpatch18',
                  version   => 1,
                  sql_stmt  => 'SELECT action_time, action, target_version,
                                       patch_type, target_build_timestamp,
                                       description
                                FROM sys.dba_registry_sqlpatch
                                WHERE status = ''SUCCESS''
                                ORDER BY action_time desc');

  sat_collect_sql(name      => 'roles',
                  version   => 1,
                  sql_stmt  => 'SELECT role 
                                FROM sys.dba_roles
                                ORDER BY role'); 

  sat_collect_sql(name      => 'roles',
                  version   => 11,
                  sql_stmt  => 'SELECT role, oracle_maintained is_oracle 
                                FROM sys.dba_roles
                                ORDER BY role',
                  bool_expr => 'is_oracle,y.*;'); 

  sat_collect_sql(name      => 'parameters',
                  version   => 1,
                  sql_stmt  => 'SELECT name, value, isdefault is_default
                                FROM sys.v_$parameter 
                                ORDER BY name',
                  bool_expr => 'is_default,true;'); 

  sat_collect_sql(name      => 'role_grants',
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, granted_role,
                                       admin_option is_admin,
                                       default_role is_default
                                FROM sys.dba_role_privs
                                WHERE grantee NOT IN (''SYS'')
                                ORDER BY grantee, granted_role',
                  bool_expr => 'is_admin,y.*;is_default,y.*;'); 


  sat_collect_sql(name      => 'role_grants',
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, granted_role, 
                                       admin_option is_admin, common,
                                       default_role is_default 
                                FROM sys.dba_role_privs
                                WHERE grantee NOT IN (''SYS'')
                                ORDER BY grantee, granted_role',
                  bool_expr => 'is_admin,y.*;is_default,y.*;'); 

  sat_collect_sql(name      => 'sys_role_grants',
                  version   => 1,
                  sql_stmt  => 'SELECT granted_role 
                                FROM sys.dba_role_privs 
                                WHERE grantee = ''SYS''
                                AND COMMON = ''NO''
                                ORDER BY granted_role');

  sat_collect_sql(name      => 'cbac_role_grants',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, object_name procedure,
                                     object_type type, role 
                                FROM sys.dba_code_role_privs');

   sat_collect_sql(name      => 'cbac_user_privs',
                  version   => 1,
                  sql_stmt  => 'SELECT dt.grantee, dt.table_name, dt.owner 
                                FROM sys.dba_tab_privs dt, 
                                     sys.dba_code_role_privs dc
                                WHERE dt.owner = dc.owner
                                AND dt.table_name = dc.object_name
                                AND dt.type = dc.object_type
                                ORDER by grantee, table_name');

  sat_collect_sql(name      => 'system_privs',
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, privilege,
                                       admin_option is_admin  
                                FROM sys.dba_sys_privs 
                                WHERE grantee NOT IN (''SYS'')
                                ORDER BY grantee, privilege',
                  bool_expr => 'is_admin,y.*;');


  sat_collect_sql(name      => 'system_privs',
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, privilege, common,
                                       admin_option is_admin  
                                FROM sys.dba_sys_privs 
                                WHERE grantee NOT IN (''SYS'')
                                ORDER BY grantee, privilege',
                  bool_expr => 'is_admin,y.*;'); 

  sat_collect_sql(name      => 'execute_privs',
                  version   => 2,
                  sql_stmt  => 'SELECT grantee, privilege, table_name package, 
                                       grantable is_admin
                                FROM sys.dba_tab_privs
                                WHERE grantee NOT IN (''SYS'') AND
                                      owner IN (''SYS'', ''AUDSYS'') AND
                                      table_name in (''UTL_SMTP'', ''UTL_FILE'',
                                        ''UTL_TCP'', ''UTL_HTTP'', ''DBMS_LOB'',
                                        ''DBMS_SYS_SQL'', ''DBMS_JOB'',
                                        ''DBMS_BACKUP_RESTORE'', ''DBMS_FGA'',
                                        ''DBMS_PRIVILEGE_CAPTURE'',
                                        ''DBMS_RLS'', ''DBMS_REDACT'',
                                        ''DBMS_TSDP_PROTECT'',
                                        ''DBMS_TSDP_MANAGE'',
                                        ''DBMS_AUDIT_MGMT'')
                                ORDER BY grantee, privilege, package',
                  bool_expr => 'is_admin,y.*;'); 


  sat_collect_sql(name      => 'execute_privs',
                  version   => 3,
                  sql_stmt  => 'SELECT grantee, privilege, table_name package, common, 
                                       grantable is_admin 
                                FROM sys.dba_tab_privs 
                                WHERE grantee NOT IN (''SYS'') AND
                                      owner IN (''SYS'', ''AUDSYS'') AND
                                      table_name in (''UTL_SMTP'', ''UTL_FILE'', 
                                        ''UTL_TCP'', ''UTL_HTTP'', ''DBMS_LOB'', 
                                        ''DBMS_SYS_SQL'', ''DBMS_JOB'', 
                                        ''DBMS_BACKUP_RESTORE'', ''DBMS_FGA'', 
                                        ''DBMS_PRIVILEGE_CAPTURE'', 
                                        ''DBMS_RLS'', ''DBMS_REDACT'', 
                                        ''DBMS_TSDP_PROTECT'', 
                                        ''DBMS_TSDP_MANAGE'',
                                        ''DBMS_AUDIT_MGMT'') 
                                ORDER BY grantee, privilege, package',
                  bool_expr => 'is_admin,y.*;'); 

  sat_collect_sql(name      => 'sensitive_obj_privs', 
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name,
                                      grantable is_admin
                                FROM sys.dba_tab_privs
                                JOIN sys.dba_tables USING (owner, table_name)
                                WHERE grantee NOT IN (''SYS'') AND
                                      privilege IN (''INSERT'', ''UPDATE'',
                                                    ''DELETE'') AND
                                      owner in (''SYS'', ''DVSYS'',
                                                ''LBACSYS'', ''AUDSYS'') AND
                                      temporary = ''N''
                                ORDER BY grantee, privilege, owner,
                                         table_name',
                  bool_expr => 'is_admin,y.*;');


  sat_collect_sql(name      => 'sensitive_obj_privs', 
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name, 
                                      grantable is_admin, common 
                                FROM sys.dba_tab_privs 
                                JOIN sys.dba_tables USING (owner, table_name)
                                WHERE grantee NOT IN (''SYS'') AND 
                                      privilege IN (''INSERT'', ''UPDATE'', 
                                                    ''DELETE'') AND 
                                      owner in (''SYS'', ''DVSYS'', 
                                                ''LBACSYS'', ''AUDSYS'') AND
                                      temporary = ''N''
                                ORDER BY grantee, privilege, owner, 
                                         table_name',
                  bool_expr => 'is_admin,y.*;');

  sat_collect_sql(name      => 'audit_obj_privs', 
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name,
                                      grantable is_admin
                                FROM sys.dba_tab_privs
                                WHERE table_name IN (''AUD$'', 
                                      ''AUDIT$'', ''AUD_POLICY$'',
                                      ''AUD_OBJECT_OPT$'', ''AUDIT_NG$'',
                                      ''AUD_CONTEXT$'',''STMT_AUDIT_OPTION_MAP'',
                                      ''METAAUDIT$'', ''SYS_FBA_CONTEXT_AUD'',
                                      ''AUDIT_ACTIONS'',
                                      ''UNIFIED_MISC_AUDITED_ACTIONS'',
                                      ''ALL_UNIFIED_AUDIT_ACTIONS'',
                                      ''AUDTAB$TBS$FOR_EXPORT_TBL'',
                                      ''AUD$UNIFIED'', ''OLS$AUDIT'',
                                      ''OLS$AUDIT_ACTIONS'',''AUDIT_TRAIL$'') AND 
                                      privilege IN (''INSERT'', ''UPDATE'',
                                                    ''DELETE'',''SELECT'') AND 
                                      owner in (''SYS'', ''DVSYS'', 
                                                ''LBACSYS'', ''AUDSYS'')  
                                ORDER BY grantee, privilege, owner,
                                         table_name',
                  bool_expr => 'is_admin,y.*;');


  sat_collect_sql(name      => 'audit_obj_privs', 
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name,
                                      grantable is_admin, common
                                FROM sys.dba_tab_privs
                                WHERE table_name IN (''AUD$'', 
                                      ''AUDIT$'', ''AUD_POLICY$'',
                                      ''AUD_OBJECT_OPT$'', ''AUDIT_NG$'',
                                      ''AUD_CONTEXT$'',''STMT_AUDIT_OPTION_MAP'',
                                      ''METAAUDIT$'', ''SYS_FBA_CONTEXT_AUD'',
                                      ''AUDIT_ACTIONS'',
                                      ''UNIFIED_MISC_AUDITED_ACTIONS'',
                                      ''ALL_UNIFIED_AUDIT_ACTIONS'',
                                      ''AUDTAB$TBS$FOR_EXPORT_TBL'',
                                      ''AUD$UNIFIED'', ''OLS$AUDIT'',
                                      ''OLS$AUDIT_ACTIONS'',''AUDIT_TRAIL$'') AND 
                                      privilege IN (''INSERT'', ''UPDATE'',
                                                    ''DELETE'',''SELECT'') AND 
                                      owner in (''SYS'', ''DVSYS'', 
                                                ''LBACSYS'', ''AUDSYS'')  
                                ORDER BY grantee, privilege, owner,
                                         table_name',
                  bool_expr => 'is_admin,y.*;');

  sat_collect_sql(name      => 'verifier_privs', 
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name,
                                      grantable is_admin
                                FROM sys.dba_tab_privs
                                WHERE grantee NOT IN (''SYS'') AND
                                      privilege IN (''SELECT'', ''READ'') AND
                                      owner = ''SYS'' AND
                                      table_name IN (''USER$'', ''LINK$'',
                                                     ''USER_HISTORY$'',
                                                     ''SCHEDULER$_CREDENTIAL'',
                                                     ''CDB_LOCAL_ADMINAUTH$'')
                                ORDER BY grantee, privilege, owner,
                                         table_name',
                  bool_expr => 'is_admin,y.*;');


  sat_collect_sql(name      => 'verifier_privs', 
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name, 
                                      grantable is_admin, common 
                                FROM sys.dba_tab_privs 
                                WHERE grantee NOT IN (''SYS'') AND 
                                      privilege IN (''SELECT'', ''READ'', ''UPDATE'') AND 
                                      owner = ''SYS'' AND
                                      table_name IN (''USER$'', ''LINK$'',
                                                     ''USER_HISTORY$'',
                                                     ''SCHEDULER$_CREDENTIAL'',
                                                     ''CDB_LOCAL_ADMINAUTH$'')
                                ORDER BY grantee, privilege, owner, 
                                         table_name',
                  bool_expr => 'is_admin,y.*;');

  sat_collect_sql(name      => 'column_privs',
                  version   => 0,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name, 
                                       column_name, grantable is_admin
                                FROM sys.dba_col_privs 
                                WHERE grantee NOT IN (''SYS'') 
                                ORDER BY grantee, privilege',
                  bool_expr => 'is_admin,y.*;');


  sat_collect_sql(name      => 'column_privs',
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, privilege, owner, table_name, 
                                       column_name, grantable is_admin, common
                                FROM sys.dba_col_privs 
                                WHERE grantee NOT IN (''SYS'') 
                                ORDER BY grantee, privilege',
                  bool_expr => 'is_admin,y.*;');

  sat_collect_sql(name      => 'user_account',
                  version   => 1,
                  sql_stmt  => 'SELECT username, account_status status, 
                                       expiry_date, profile, 
                                       default_tablespace,
                                       temporary_tablespace, created 
                                FROM sys.dba_users 
                                ORDER BY username');

  sat_collect_sql(name      => 'user_account',
                  version   => 13,
                  sql_stmt  => 'SELECT username, password_versions, 
                                       account_status status, expiry_date, 
                                       profile, default_tablespace, 
                                       temporary_tablespace, created, 
                                       authentication_type, external_name
                                FROM sys.dba_users 
                                ORDER BY username');

  sat_collect_sql(name      => 'user_account',
                  version   => 22,
                  sql_stmt  => 'SELECT username, password_versions, 
                                       account_status status, expiry_date, 
                                       profile, default_tablespace, 
                                       temporary_tablespace, created,
                                       oracle_maintained oracle_supplied, 
                                       last_login, authentication_type, 
                                       external_name
                                FROM sys.dba_users 
                                ORDER BY username',
                  bool_expr => 'oracle_supplied,y.*;');


  sat_collect_sql(name      => 'user_account',
                  version   => 23,
                  sql_stmt  => 'SELECT username, password_versions, 
                                       account_status status, expiry_date, 
                                       profile, default_tablespace, 
                                       temporary_tablespace, created, common,  
                                       oracle_maintained oracle_supplied, 
                                       last_login, authentication_type, 
                                       external_name
                                FROM sys.dba_users 
                                ORDER BY username',
                  bool_expr => 'oracle_supplied,y.*;');

  sat_collect_sql(name      => 'user_password_file',
                  version   => 1,
                  sql_stmt  => 'SELECT username, sysdba, sysoper 
                                FROM sys.v_$pwfile_users 
                                ORDER BY username',
                  bool_expr => 'sysdba,true;sysoper,true;');

  sat_collect_sql(name      => 'user_password_file',
                  version   => 11,
                  sql_stmt  => 'SELECT username, sysdba, sysoper, sysasm, 
                                       sysbackup, sysdg, syskm 
                                FROM sys.v_$pwfile_users 
                                ORDER BY username',
                  bool_expr => 'sysdba,true;sysoper,true;sysasm,true;' || 
                               'sysbackup,true;sysdg,true;syskm,true;');

  sat_collect_sql(name      => 'user_password_file',
                  version   => 21,
                  sql_stmt  => 'SELECT username, sysdba, sysoper, sysasm, 
                                       sysbackup, sysdg, syskm, account_status,
                                       password_profile, last_login, 
                                       authentication_type
                                FROM sys.v_$pwfile_users 
                                ORDER BY username',
                  bool_expr => 'sysdba,true;sysoper,true;sysasm,true;' || 
                               'sysbackup,true;sysdg,true;syskm,true;');

  sat_collect_sql(name      => 'user_password_file',
                  version   => 22,
                  sql_stmt  => 'SELECT username, sysdba, sysoper, sysasm, 
                                       sysbackup, sysdg, syskm, account_status,
                                       password_profile, last_login, 
                                       authentication_type, common 
                                FROM sys.v_$pwfile_users 
                                ORDER BY username',
                  bool_expr => 'sysdba,true;sysoper,true;sysasm,true;' ||
                               'sysbackup,true;sysdg,true;syskm,true;' ||
                               'common,YES;');

  sat_collect_sql(name      => 'profiles',
                  version   => 1,
                  sql_stmt  => 'SELECT profile, resource_name, limit 
                                FROM sys.dba_profiles 
                                ORDER BY profile, resource_name');

  sat_collect_sql(name      => 'user_with_default_password',
                  version   => 1,
                  sql_stmt  => 'SELECT a.username, 
                                       b.account_status account_open,
                                       b.lock_date, b.created 
                                FROM sys.dba_users_with_defpwd a, 
                                     sys.dba_users b 
                                WHERE a.username=b.username 
                                ORDER BY b.account_status, a.username',
                  bool_expr => 'account_open,open;');

  sat_collect_sql(name      => 'directory_info',
                  version   => 1,
                  sql_stmt  => 'SELECT directory_name, directory_path 
                                FROM sys.dba_directories 
                                ORDER BY directory_name');

  sat_collect_sql(name      => 'directory_priv',
                  version   => 1,
                  sql_stmt  => 'SELECT p.table_name, directory_name, p.grantee,
                                       p.privilege
                                FROM sys.dba_tab_privs p, sys.dba_directories d
                                WHERE p.owner = ''SYS'' AND
                                      p.privilege IN (''READ'', ''WRITE'', 
                                                       ''EXECUTE'') AND
                                      p.table_name = d.directory_name AND
                                      p.owner = d.owner 
                                ORDER BY p.table_name , p.grantee, 
                                                        p.privilege');


  sat_collect_sql(name      => 'directory_priv',
                  version   => 2,
                  sql_stmt  => 'SELECT p.table_name, directory_name, p.grantee,
                                       p.privilege, common
                                FROM sys.dba_tab_privs p, sys.dba_directories d
                                WHERE p.owner = ''SYS'' AND
                                      p.privilege IN (''READ'', ''WRITE'', 
                                                       ''EXECUTE'') AND
                                      p.table_name = d.directory_name AND
                                      p.owner = d.owner 
                                ORDER BY p.table_name , p.grantee, 
                                                        p.privilege');

  sat_collect_sql(name      => 'directory_priv',
                  version   => 11,
                  sql_stmt  => 'SELECT table_name directory_name, grantee, 
                                       privilege
                                FROM sys.dba_tab_privs
                                WHERE type = ''DIRECTORY''
                                ORDER BY directory_name, grantee, privilege');


  sat_collect_sql(name      => 'directory_priv',
                  version   => 12,
                  sql_stmt  => 'SELECT table_name directory_name, grantee, 
                                       privilege, common 
                                FROM sys.dba_tab_privs 
                                WHERE type = ''DIRECTORY'' 
                                ORDER BY directory_name, grantee, privilege');

  sat_collect_sql(name      => 'db_links',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, db_link, username, host
                                FROM sys.dba_db_links
                                ORDER BY db_link');

  sat_collect_sql(name      => 'data_files',
                  version   => 1,
                  sql_stmt  => 'SELECT file_name, status is_avail
                                FROM sys.dba_data_files
                                ORDER BY file_name',
                  bool_expr => 'is_avail,available;');

  sat_collect_sql(name      => 'triggers',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, trigger_name, status, 
                                       triggering_event 
                                FROM sys.dba_triggers 
                                ORDER BY owner, trigger_name');

  sat_collect_sql(name      => 'vpd_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, pf_owner, function, 
                                       object_owner, object_name 
                                FROM sys.dba_policies 
                                WHERE pf_owner <> ''XDB'' 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'vpd_policy_columns',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, object_owner, object_name, 
                                       sec_rel_column, column_option
                                FROM sys.dba_sec_relevant_cols 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'vpd_policy_columns',
                  version   => 2,
                  sql_stmt  => 'SELECT policy_name, object_owner, object_name, 
                                       sec_rel_column, column_option, common
                                FROM sys.dba_sec_relevant_cols 
                                ORDER BY policy_name');


  sat_collect_sql(name      => 'redaction_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, p.object_owner, 
                                       p.object_name, column_name 
                                FROM sys.redaction_policies p, 
                                     sys.redaction_columns c
                                WHERE p.object_owner = c.object_owner AND 
                                      p.object_name = c.object_name 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'tsdp_sensitive_type_col',
                  version   => 1,
                  sql_stmt  => 'SELECT sensitive_type, schema_name, table_name, 
                                       column_name 
                                FROM sys.dba_sensitive_data 
                                ORDER BY sensitive_type, schema_name, 
                                         table_name, column_name');

  sat_collect_sql(name      => 'tsdp_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, security_feature 
                                FROM sys.dba_tsdp_policy_feature 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'option_check',
                  version   => 1,
                  sql_stmt  => 'SELECT parameter, value 
                                FROM sys.v_$option 
                                ORDER BY parameter',
                  bool_expr => 'value,true;');

  sat_collect_sql(name      => 'privilege_capture',
                  version   => 2,
                  sql_stmt  => 'SELECT dpc.name name, dpc.type type, 
                                       dpc.enabled enabled, 
                                       MAX(crl.start_time) last_begin, 
                                       MAX(crl.end_time) last_end 
                                FROM sys.dba_priv_captures dpc, 
                                     sys.capture_run_log$ crl 
                                RIGHT OUTER JOIN sys.priv_capture$ pc 
                                ON crl.capture = pc.id# 
                                WHERE dpc.name <> ''ORA$DEPENDENCY'' AND 
                                      dpc.name = pc.name 
                                GROUP BY dpc.name, dpc.type, dpc.enabled 
                                ORDER BY dpc.name',
                  bool_expr => 'enabled,y;');

  sat_collect_sql(name      => 'ols_schema_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, schema_name, status 
                                FROM sys.dba_sa_schema_policies 
                                ORDER BY policy_name, schema_name',
                  bool_expr => 'status,enabled;');

  sat_collect_sql(name      => 'ols_table_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, schema_name, table_name, 
                                       status
                                FROM sys.dba_sa_table_policies 
                                ORDER BY policy_name, schema_name, table_name',
                  bool_expr => 'status,enabled;');

  sat_collect_sql(name      => 'dv_realm',
                  version   => 1,
                  sql_stmt  => 'SELECT name, enabled 
                                FROM dvsys.dba_dv_realm 
                                ORDER BY name',
                  bool_expr => 'enabled,y;');

  sat_collect_sql(name      => 'dv_realm',
                  version   => 12,
                  sql_stmt  => 'SELECT name, realm_type, enabled, 
                                       oracle_supplied 
                                FROM dvsys.dba_dv_realm 
                                ORDER BY name',
                  bool_expr => 'enabled,y;oracle_supplied,yes;');

  sat_collect_sql(name      => 'dv_realm_object',
                  version   => 1,
                  sql_stmt  => 'SELECT realm_name, owner, object_name, 
                                       object_type
                                FROM dvsys.dba_dv_realm_object 
                                ORDER BY realm_name, owner, object_name, 
                                         object_type');
   
  sat_collect_sql(name      => 'dv_command_rule',
                  version   => 1,
                  sql_stmt  => 'SELECT command, object_owner, object_name, 
                                       rule_set_name, enabled 
                                FROM dvsys.dba_dv_command_rule 
                                ORDER BY command, object_owner, object_name',
                  bool_expr => 'enabled, y;');

  sat_collect_sql(name      => 'dv_command_rule',
                  version   => 11,
                  sql_stmt  => 'SELECT command, object_owner, object_name, 
                                       clause_name, parameter_name, event_name,
                                       component_name, action_name, 
                                       rule_set_name, enabled, oracle_supplied 
                                FROM dvsys.dba_dv_command_rule 
                                ORDER BY command, object_owner, object_name, 
                                         clause_name, parameter_name',
                  bool_expr => 'enabled, y;oracle_supplied,yes;');

  sat_collect_sql(name      => 'dv_status',
                  version   => 1,
                  sql_stmt  => 'SELECT name, status, con_ID 
                                FROM sys.cdb_dv_status');

  sat_collect_sql(name      => 'encryption_wallet',
                  version   => 2,
                  sql_stmt  => 'SELECT wrl_type, wrl_parameter, status 
                                FROM sys.v_$encryption_wallet');

  sat_collect_sql(name      => 'encryption_wallet',
                  version   => 11,
                  sql_stmt  => 'SELECT wrl_type, wrl_parameter, status, 
                                       wallet_type, wallet_order 
                                FROM sys.v_$encryption_wallet');

  sat_collect_sql(name      => 'encrypted_column',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, table_name, column_name, 
                                       encryption_alg 
                                FROM sys.dba_encrypted_columns 
                                ORDER BY owner, table_name, column_name');

  sat_collect_sql(name      => 'encrypted_tablespace',
                  version   => 2,
                  sql_stmt  => 'SELECT distinct t.name, et.encryptionalg algo 
                                FROM sys.v_$encrypted_tablespaces et 
                                RIGHT OUTER JOIN sys.v_$tablespace t 
                                ON et.ts# = t.ts# 
                                ORDER BY t.name');
   
  sat_collect_sql(name      => 'java_permission',
                  version   => 1,
                  sql_stmt  => 'SELECT grantee, kind, type_name, type_schema, 
                                       name, action 
                                FROM sys.dba_java_policy 
                                WHERE grantee not LIKE ''JAVA%'' AND 
                                      grantee <> ''SYS'' 
                                ORDER BY grantee, kind');

  sat_collect_sql(name      => 'external_procedure',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, library_name, dynamic, status 
                                FROM sys.dba_libraries 
                                WHERE file_spec IS NOT NULL 
                                ORDER BY owner, library_name',
                  bool_expr => 'dynamic,y;');

  sat_collect_sql(name      => 'network_acl',
                  version   => 1,
                  sql_stmt  => 'SELECT host, lower_port, upper_port, acl 
                                FROM sys.dba_network_acls 
                                ORDER BY host');

  sat_collect_sql(name      => 'network_acl_privilege',
                  version   => 1,
                  sql_stmt  => 'SELECT acl, principal, privilege, is_grant, 
                                       invert, start_date, end_date 
                                FROM sys.dba_network_acl_privileges 
                                ORDER BY acl, principal, privilege',
                  bool_expr => 'is_grant,true;');

  sat_collect_sql(name      => 'xml_acl',
                  version   => 1,
                  sql_stmt  => 'SELECT to_char(XMLTYPE.getclobval(SYS_NC_ROWINFO$)) xml_acl 
                                FROM xdb.xdb$acl');

  sat_collect_sql(name      => 'statement_audit',
                  version   => 1,
                  sql_stmt  => 'SELECT user_name, proxy_name, audit_option 
                                FROM sys.dba_stmt_audit_opts 
                                ORDER BY user_name, audit_option');

  sat_collect_sql(name      => 'object_audit',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, object_type, object_name, sel, 
                                       upd, ins, del, exe, alt 
                                FROM sys.dba_obj_audit_opts 
                                ORDER by owner, object_name, object_type');

  sat_collect_sql(name      => 'privilege_audit',
                  version   => 1,
                  sql_stmt  => 'SELECT user_name, proxy_name, privilege 
                                FROM sys.dba_priv_audit_opts 
                                ORDER BY user_name, privilege');

  sat_collect_sql(name      => 'fine_grained_audit',
                  version   => 1,
                  sql_stmt  => 'SELECT object_schema, object_name, policy_name, 
                                       policy_text, policy_column, enabled, 
                                       sel, ins, upd, del 
                                FROM sys.dba_audit_policies 
                                ORDER BY policy_name, object_schema, 
                                         object_name',
                  bool_expr => 'enabled,yes;');

  sat_collect_sql(name      => 'traditional_audit_trail',
                  version   => 2,
                  sql_stmt  => 'SELECT count(*) num, 
                                MIN(extended_timestamp) min_date,
                                MAX(extended_timestamp) max_date 
                                FROM sys.dba_audit_trail');

  sat_collect_sql(name      => 'fine_grained_audit_trail',
                  version   => 2,
                  sql_stmt  => 'SELECT count(*) num,
                                MIN(extended_timestamp) min_date,
                                MAX(extended_timestamp) max_date
                                FROM sys.dba_fga_audit_trail');

  sat_collect_sql(name      => 'unified_audit_policy',
                  version   => 1,
                  sql_stmt  => 'SELECT policy_name, count(*) num, 
                                       (CASE WHEN policy_name IN 
                                          (SELECT DISTINCT policy_name 
                                           FROM sys.audit_unified_enabled_policies) 
                                        THEN ''Enabled'' 
                                        ELSE ''Disabled'' END) state 
                                FROM sys.audit_unified_policies 
                                GROUP By policy_name 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'unified_audit_details',
                  version   => 2,
                  sql_stmt  => 'SELECT p.policy_name, p.audit_option, 
                                       p.audit_option_type, p.object_schema, 
                                       p.object_name, p.object_type, 
                                       ep.user_name 
                                FROM sys.audit_unified_policies p, 
                                     sys.audit_unified_enabled_policies ep 
                                WHERE p.policy_name = ep.policy_name 
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'unified_audit_details',
                  version   => 3,
                  sql_stmt  => 'SELECT p.policy_name, p.audit_option,
                                       p.audit_option_type, p.object_schema,
                                       p.object_name, p.object_type,
                                       ep.entity_name user_name
                                FROM sys.audit_unified_policies p,
                                     sys.audit_unified_enabled_policies ep
                                WHERE p.policy_name = ep.policy_name AND 
                                      ep.entity_type = ''USER''
                                ORDER BY policy_name');

  sat_collect_sql(name      => 'unified_audit_roles',
                  version   => 1,
                  sql_stmt  => 'SELECT p.policy_name, p.audit_option,
                                       p.audit_option_type, p.object_schema,
                                       p.object_name, p.object_type,
                                       ep.entity_name role_name
                                FROM sys.audit_unified_policies p,
                                     sys.audit_unified_enabled_policies ep
                                WHERE p.policy_name = ep.policy_name AND
                                      ep.entity_type = ''ROLE''
                                ORDER BY policy_name');



  BEGIN
    SELECT version INTO db_version FROM sys.v_$instance;
  EXCEPTION
    WHEN OTHERS THEN
      db_version := '';
  END;

  IF db_version LIKE '12.1.0.2.%' THEN
     sat_collect_sql(name      => 'unified_audit_trail',
                     version   => 1,
                     sql_stmt  => 'SELECT count(*) num 
                                   FROM sys.unified_audit_trail 
                                   WHERE rownum = 1');
  END IF;

  sat_collect_sql(name      => 'unified_audit_trail_stats',
                  version   => 1,
                  sql_stmt  => 'SELECT count(*) num,
                                MIN(event_timestamp) min_date,
                                MAX(event_timestamp) max_date 
                                FROM audsys.unified_audit_trail');

  sat_collect_sql(name      => 'ras_policy',
                  version   => 2,
                  sql_stmt  => 'SELECT policy_owner, policy policy_name, 
                                       schema, object, owner_bypass 
                                FROM sys.dba_xs_policies, 
                                     sys.dba_xs_applied_policies 
                                WHERE name = policy AND owner = policy_owner 
                                ORDER BY policy_owner, policy',
                  bool_expr => 'owner_bypass,yes;');

  sat_collect_sql(name      => 'ras_privs',
                  version   => 1,
                  sql_stmt  => 'SELECT principal, privilege 
                                FROM sys.dba_xs_aces 
                                WHERE principal_type = ''DATABASE'' 
                                ORDER BY principal, privilege');

  sat_collect_sql(name      => 'disabled_constraint',
                  version   => 1,
                  sql_stmt  => 'SELECT owner, table_name, constraint_type, 
                                       constraint_name, last_change, status 
                                FROM sys.dba_constraints 
                                WHERE status <> ''ENABLED'' AND 
                                      owner NOT IN (''SYS'',''SYSTEM'') 
                                ORDER BY owner, table_name, constraint_type, 
                                         constraint_name');

  sat_collect_sql(name       => 'rman_backup_status',
                 version    => 1,
                 sql_stmt   => 'SELECT object_type, max(end_time) ctime, 
                                       output_device_type 
                                FROM sys.v_$rman_status 
                                WHERE operation like ''BACKUP'' AND 
                                      status = ''COMPLETED'' AND
                                      end_time >= SYSDATE - 90 
                                GROUP BY object_type, output_device_type');

  sat_collect_sql(name      => 'bkup_piece_enc',
                  version   => 1,
                  sql_stmt  => 'SELECT encrypted, count(*) num
                                FROM sys.v_$backup_piece 
                                WHERE completion_time >= SYSDATE - 90 AND
                                      status = ''A''
                                GROUP BY encrypted');

  sat_collect_sql(name      => 'cloud_service',
                  version   => 1,
                  sql_stmt  => 'SELECT count(service) cs 
                                FROM (SELECT sys_context(''USERENV'', ''CLOUD_SERVICE'') service 
                                      FROM sys.dual)');

END;
/
SPOOL OFF

SET TERMOUT ON 
BEGIN
  SYS.DBMS_OUTPUT.PUT_LINE('SQL queries complete.');
  IF LENGTH(:err_buf) > 0 THEN
    SYS.DBMS_OUTPUT.PUT_LINE('Errors were found in the following queries:');
    SYS.DBMS_OUTPUT.PUT_LINE(:err_buf);
  END IF;
END;
/
SET TERMOUT OFF 

DECLARE
  v_server_machine       VARCHAR2(64);
  v_client_machine       VARCHAR2(64);
  v_cs                   VARCHAR2(64);
  v_pfid                 NUMBER;
  v_code                 NUMBER;
  PLATFORM_WINDOWS_IA32   CONSTANT BINARY_INTEGER := 7;
  PLATFORM_WINDOWS_IA64   CONSTANT BINARY_INTEGER := 8;
  PLATFORM_WINDOWS_X86_64 CONSTANT BINARY_INTEGER := 12;
BEGIN
  SELECT HOST_NAME INTO v_server_machine FROM sys.v_$instance;

  SELECT UNIQUE MACHINE INTO v_client_machine FROM sys.v_$session 
  WHERE SID = SYS_CONTEXT('USERENV', 'SID');

  SELECT platform_id INTO v_pfid FROM sys.v_$database;

  SELECT SYS_CONTEXT('USERENV', 'CLOUD_SERVICE') into v_cs from sys.dual;

  IF (v_pfid <> PLATFORM_WINDOWS_IA32 AND
      v_pfid <> PLATFORM_WINDOWS_IA64 AND
      v_pfid <> PLATFORM_WINDOWS_X86_64) AND
      (v_cs IS NULL OR 
      (v_cs <> 'DWCS' AND v_cs <> 'OLTP' AND v_cs <> 'PAAS')) AND 
      v_server_machine = v_client_machine THEN
    SELECT 'N' INTO :skip_os FROM sys.DUAL;
  END IF;
  EXCEPTION 
    WHEN OTHERS THEN 
      v_code := SQLCODE;
      IF(v_code = -2003) THEN
        IF (v_pfid <> PLATFORM_WINDOWS_IA32 AND
            v_pfid <> PLATFORM_WINDOWS_IA64 AND
            v_pfid <> PLATFORM_WINDOWS_X86_64) AND
            v_server_machine = v_client_machine THEN
          SELECT 'N' INTO :skip_os FROM sys.DUAL;
        END IF;
      END IF;
END;
/

SPOOL &x_spool_file APPEND
BEGIN
 IF :skip_os = 'Y' THEN
   SYS.DBMS_OUTPUT.PUT_LINE('"OS Commands Skipped": {}}');
 END IF; 
END;
/
SPOOL OFF

WHENEVER SQLERROR EXIT
SET TERMOUT ON 
BEGIN
  IF :skip_os = 'Y' THEN
    SYS.DBMS_OUTPUT.PUT_LINE('OS Commands Skipped.');
    RAISE_APPLICATION_ERROR(-20002, 'Complete without OS Commands.');
  END IF;
END;
/
SET TERMOUT OFF 

WHENEVER SQLERROR CONTINUE
WHENEVER OSERROR CONTINUE 

var filter_stmt VARCHAR2(500);
column stmt_col new_value x_filter_stmt noprint

exec :filter_stmt := 'open(CMD, $ARGV[1]."|"); @lines = <CMD>; close(CMD); if ($?) {print STDERR "Warning: Exit status $? from OS rule: $ARGV[0]\n"; } printf("\"%s\": {\"version\": 1,\n", $ARGV[0]); print "\t\"columns\": [\"result\"],\n"; print "\t\"data\": [\n"; foreach (@lines) { if ($line++ > 0) { print ",\n"; } chomp; s/\\/\\\\/g; s/\"/\\\"/g; printf("\t\t[\"%s\"]", $_); } print "]},\n";';
select :filter_stmt stmt_col from sys.dual;

host /usr/bin/perl -e '&x_filter_stmt' 'environment' '/bin/env' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'dbs_file_permission' '/bin/ls -alL $ORACLE_HOME/dbs' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'executable_permission' '/bin/ls -alL $ORACLE_HOME/bin' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'library_permission' '/bin/ls -alL $ORACLE_HOME/lib' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'oracle_home_owner' '/bin/ls -lLd $ORACLE_HOME | perl -ne "@f=split(); print \$f[2].chr(10);"' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'processes' '/bin/ps -ef | perl -ne "print if !(/dbsat collect/)"' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sqlnet.ora' '/bin/cat $TNS_ADMIN/sqlnet.ora 2> /dev/null || /bin/cat $ORACLE_HOME/network/admin/sqlnet.ora' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'ls_sqlnet.ora' '/bin/ls -lL $TNS_ADMIN/sqlnet.ora 2> /dev/null || /bin/ls -lL $ORACLE_HOME/network/admin/sqlnet.ora' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'listener.ora' '/bin/cat $TNS_ADMIN/listener.ora 2> /dev/null || /bin/cat $ORACLE_HOME/network/admin/listener.ora' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'ls_listener.ora' '/bin/ls -lL $TNS_ADMIN/listener.ora 2> /dev/null || /bin/ls -lL $ORACLE_HOME/network/admin/listener.ora' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'os_password_file' '/bin/cat /etc/passwd' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'os_group_file' '/bin/cat /etc/group' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'osdba_group' '$ORACLE_HOME/bin/osdbagrp -d 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sysasm_group' '$ORACLE_HOME/bin/osdbagrp -a 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sysoper_group' '$ORACLE_HOME/bin/osdbagrp -o 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sysbackup_group' '$ORACLE_HOME/bin/osdbagrp -b 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sysdg_group' '$ORACLE_HOME/bin/osdbagrp -g 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'syskm_group' '$ORACLE_HOME/bin/osdbagrp -k 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'sysrac_group' '$ORACLE_HOME/bin/osdbagrp -r 2>/dev/null || /bin/true' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'opatch_inventory' '$ORACLE_HOME/OPatch/opatch lsinventory </dev/null' >> &x_spool_file

host /usr/bin/perl -e '&x_filter_stmt' 'lsnr_stat' '$ORACLE_HOME/bin/lsnrctl status | perl -ne "print if /Security/" | perl -ne "print if /ON:Password or Local OS Authentication/"' >> &x_spool_file

SET TERMOUT ON 
exec SYS.DBMS_OUTPUT.PUT_LINE('OS commands complete.');
SET TERMOUT OFF 


SPOOL &x_spool_file APPEND
BEGIN
  SYS.DBMS_OUTPUT.PUT_LINE('"END": {"version": 29,');
  SYS.DBMS_OUTPUT.PUT_LINE(chr(9) || '"columns": ["release"],');
  SYS.DBMS_OUTPUT.PUT_LINE(chr(9) || '"data": [["' || :version || '"]]}');
  SYS.DBMS_OUTPUT.PUT_LINE('}');
END;
/
SPOOL OFF

QUIT
